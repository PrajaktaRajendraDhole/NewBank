﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;



namespace NewBank
{
    class mainBank
    {
        private static string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BankDatabase;Integrated Security=True";

        public static void createAcc(string accno, string accHoldName, double initialBalance)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO BankAccounts (ACCNO, ACCHOLDNAME, BALANCE) VALUES (@accno, @accholdname, @balance)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@accno", accno);
                    command.Parameters.AddWithValue("@accholdname", accHoldName);
                    command.Parameters.AddWithValue("@balance", initialBalance);

                    command.ExecuteNonQuery();
                }
            }

            Console.WriteLine("Account created successfully!");
        }

        public static Bankacc getacc(string accno)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM BankAccounts WHERE ACCNO = @accno";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@accno", accno);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string accNo = reader["ACCNO"].ToString();
                            string accHoldName = reader["ACCHOLDNAME"].ToString();
                            double balance = Convert.ToDouble(reader["BALANCE"]);

                            return new Bankacc(accNo, accHoldName, balance);
                        }
                    }
                }
            }

            return null;
        }
        public static void Deposit(string accno, double amount)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "UPDATE BankAccounts SET BALANCE = BALANCE + @amount WHERE ACCNO = @accno";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@accno", accno);
                    command.Parameters.AddWithValue("@amount", amount);

                    command.ExecuteNonQuery();
                }
            }

            Console.WriteLine($"Deposited ${amount}. New balance updated in the database.");
        }



        public static void ApplyLoan(String accno, double loanAmount, SqlConnection conn)
        {
            Bankacc b1 = getacc(accno);
            if (b1 != null)
            {
                b1.ApplyLoan(loanAmount, conn);
            }
        }



        public static void Transfer(string fromAccount, string toAccount, double amount)
        {
            Bankacc fromAccountObj = getacc(fromAccount);
            Bankacc toAccountObj = getacc(toAccount);

            if (fromAccountObj != null && toAccountObj != null)
            {
                // Check if the balance in the 'from' account is sufficient for the transfer
                if (fromAccountObj.BALANCE >= amount)
                {
                    // Update balances in memory
                    fromAccountObj.Withdraw(amount);
                    toAccountObj.Deposit(amount);

                    // Update balances in the database
                    Deposit(fromAccount, -amount);  // Subtract amount from 'from' account
                    Deposit(toAccount, amount);     // Add amount to 'to' account

                    Console.WriteLine($"Transfer successful. ${amount} transferred from {fromAccount} to {toAccount}.");
                }
                else
                {
                    Console.WriteLine($"Insufficient funds in {fromAccount} for the transfer.");
                }
            }
            else
            {
                Console.WriteLine("One or both of the accounts do not exist. Please check the account numbers.");
            }
        }


    }
}