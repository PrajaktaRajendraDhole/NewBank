﻿using System;
using System.ComponentModel.Design;
using System.Data.SqlClient;

namespace NewBank
{
    class Bankacc
    {
        public string ACCNO { get; }
        public string ACCHOLDNAME { get; set; }
        public double BALANCE { get; set; }
        public double Loanamount { get; private set; }

        public Bankacc(string accno, string accholdname, double bal)
        {
            ACCNO = accno;
            ACCHOLDNAME = accholdname;
            BALANCE = bal;
            Loanamount = 0;
        }

        public void Deposit(double amount)
        {
            BALANCE += amount;
            Console.WriteLine($"Deposited ${amount}. New balance: ${BALANCE}");
        }

        public void Withdraw(double amount)
        {
            if (amount > BALANCE)
            {
                Console.WriteLine("Insufficient funds. You cannot withdraw.");
            }
            else
            {
                BALANCE -= amount;
                Console.WriteLine($"Withdrawn ${amount}. New balance: ${BALANCE}");
            }
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Account number: {ACCNO}");
            Console.WriteLine($"Account holder: {ACCHOLDNAME}");
            Console.WriteLine($"Balance: ${BALANCE}");
        }
        public void ApplyLoan(double loanAmount, SqlConnection conn)
        {
            if (loanAmount <= BALANCE)
            {
                Loanamount = Loanamount + loanAmount;


                conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BankDatabase;Integrated Security=True");
                conn.Open();

                string q = $"UPDATE BankAccounts SET Loanamount = {Loanamount} WHERE ACCNO = '{ACCNO}'";
                SqlCommand updatecmd = new SqlCommand(q, conn);
                updatecmd.ExecuteNonQuery();


                Console.WriteLine($"Loan of ${loanAmount} approved.total loan amount is :${Loanamount}");
            }
            else
            {
                Console.WriteLine("loan cannot be approved ,requested amount is greater than balan ");
            }
        }
    }
}