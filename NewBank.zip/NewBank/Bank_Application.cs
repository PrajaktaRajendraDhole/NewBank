﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace NewBank
{
    class Bank_Application
    {
        //static Dictionary<String, String> userdatabase = new Dictionary<string, string>();// creating a collection similar as  java
        // dictionary is one collection in c# which takes data in key value pair
        static void Main()
        {

            SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BankDatabase;Integrated Security=True");
            conn.Open();
            Console.WriteLine("Welcome to the Bank Application");
            Console.WriteLine("======**======");

            Console.WriteLine("Enter 1. for Register");
            Console.WriteLine("Enter 2. for Login");
            Console.WriteLine("Enter 3. forExit");

            //first_step f1 = new first_step();

            int choice = first_step.GetChoice();
            while (true)
            {

                switch (choice)
                {
                    case 1:
                        first_step.register();
                        break;

                    case 2:
                        first_step.login();
                        break;

                    case 3:
                        Environment.Exit(0);
                        break;


                    default:
                        Console.WriteLine("enter vaild input");
                        break;

                }



                bool exit = false;

                while (!exit)
                {
                    Console.WriteLine("=========== welcome to bank ============");

                    Console.WriteLine(" press 1. for create bank acc");
                    Console.WriteLine(" press 2. for deposit");
                    Console.WriteLine(" press 3. for withdraw");
                    Console.WriteLine(" press 4. display account information");
                    Console.WriteLine(" press 5. for loan application");
                    Console.WriteLine(" press 6. for transfer amount");

                    Console.WriteLine(" enter exit to euit /n or press any key to continue");

                    String ip = Console.ReadLine();
                    if (ip.ToLower() == "exit")
                    {
                        exit = true;
                        break;
                    }




                    //Console.WriteLine("enter a chioce"); extra 

                    // String num = Console.ReadLine(); extraa

                    switch (ip)
                    {
                        case "1":
                            sec_step.CreateAccount();
                            break;


                        case "2":
                            sec_step.Deposit();
                            break;


                        case "3":
                            sec_step.Withdraw();
                            break;


                        case "4":
                            sec_step.DisplayAccInfo();
                            break;

                        case "5":
                            sec_step.ApplyLoan(conn);
                            break;


                         case "6":
                        sec_step.Transfer();
                          break;


                        default:
                            Console.WriteLine("enter vaild input");
                            break;



                    }

                }
                Console.WriteLine("out of while loop");
            }

        }


    }

}