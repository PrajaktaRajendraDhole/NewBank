﻿using System;
using System.Data.SqlClient;
using System.Runtime.Intrinsics.X86;
using System.Threading.Channels;


namespace NewBank
{
    class sec_step
    {
        public static void CreateAccount()

        {

            Console.WriteLine("enter account number: ");
            string accno = Console.ReadLine();

            Console.WriteLine("enter account holder's name");
            string accholdname = Console.ReadLine();

            Console.WriteLine(" enter min balance to initailize acc");
            double initialbalance;

            if (double.TryParse(Console.ReadLine(), out initialbalance))//**
            {
                mainBank.createAcc(accno, accholdname, initialbalance);
            }
            else
            {
                Console.WriteLine("invalid input for initial balance for acc creation");
            }

        }

        public static void Deposit()
        {
            Console.WriteLine("enter account number");
            string acno = Console.ReadLine();

            Bankacc b1 = mainBank.getacc(acno);

            if (b1 != null)
            {
                Console.WriteLine("enter amount that you want to deposit");
                double amount;
                if (double.TryParse(Console.ReadLine(), out amount))
                {
                    b1.Deposit(amount);  // Update balance in memory
                    mainBank.Deposit(acno, amount);  // Update balance in the database
                }
            }





        }





        public static void Withdraw()
        {
            Console.WriteLine("Enter account number");
            string accno = Console.ReadLine();

            Bankacc b1 = mainBank.getacc(accno);

            if (b1 != null)
            {
                Console.WriteLine("Enter amount that you want to withdraw: ");
                double amount;

                if (double.TryParse(Console.ReadLine(), out amount))
                {
                    b1.Withdraw(amount);  // Update balance in memory

                    // Check if withdrawal was successful before updating the database
                    if (b1.BALANCE >= 0)
                    {
                        mainBank.Deposit(accno, -amount);  // Update balance in the database (subtracting the amount)
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input for withdrawal amount");
                }
            }
            else
            {
                Console.WriteLine("Account not found. Please check the account number.");
            }
        }








        public static void DisplayAccInfo()
        {

            Console.WriteLine("enter account number");
            string acc = Console.ReadLine();
            Bankacc b1 = mainBank.getacc(acc);
            if (b1 != null)
            {
                b1.DisplayInfo();
            }




        }
        public static void ApplyLoan(SqlConnection conn)
        {

            Console.WriteLine("enter a acc no for apply loan");
            String accno = Console.ReadLine();


            Bankacc b1 = mainBank.getacc(accno);
            if (b1 != null)
            {
                Console.WriteLine("enter a loan amount");
                double loanAmount;
                if (double.TryParse(Console.ReadLine(), out loanAmount))
                {

                    b1.ApplyLoan(loanAmount, conn);
                }
                else
                {
                    Console.WriteLine("invalid input for loan application");
                }
            }

        }



        public static void Transfer()
        {
            Console.WriteLine("Enter source account number:");
            string fromAccount = Console.ReadLine();

            Console.WriteLine("Enter destination account number:");
            string toAccount = Console.ReadLine();

            Console.WriteLine("Enter amount to transfer:");
            double amount;

            if (double.TryParse(Console.ReadLine(), out amount))
            {
                mainBank.Transfer(fromAccount, toAccount, amount);
            }
            else
            {
                Console.WriteLine("Invalid input for transfer amount");
            }
        }









    }
}