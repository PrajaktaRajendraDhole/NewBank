﻿using System;
using System.Collections.Generic;
//using System.Threading.Channels;
using System.Data.SqlClient;

namespace NewBank
{
    class first_step
    {

        // dictionary is one collection in c# which takes data in key value pair
        public static int GetChoice()// in this method we are trying to check whether user enter vaild entry ot not
        {


            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }
            return choice;
        }


        public static void register()

        {
            SqlConnection conn;
            conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BankDatabase;Integrated Security=True");
            conn.Open();

            Console.WriteLine("Enter details for registration");

            Console.WriteLine("Enter your username");
            String username = Console.ReadLine();

            Console.WriteLine("Enter your password");
            String password = Console.ReadLine();

            string q = "insert into register_details(username,password)values('" + username + "','" + password + "')";

            SqlCommand cmd = new SqlCommand(q, conn);
            int row = cmd.ExecuteNonQuery();//
            if (row > 0)
            {
                Console.WriteLine("user register succefully");
            }
            else
            {
                Console.WriteLine("someething wnt wrong");
            }




            Console.WriteLine("registration sucesfully");
            Console.WriteLine("==========**============");
            login();

        }
        public static void login()
        {

            SqlConnection conn;
            conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=BankDatabase;Integrated Security=True");
            conn.Open();

            Console.WriteLine("Enter details for login");

            Console.WriteLine("enter username");
            String username = Console.ReadLine();

            Console.WriteLine("enter password");
            String password = Console.ReadLine();
            string q = "select * from register_details where username='" + username + "' AND password='" + password + "'";
            SqlCommand cmd = new SqlCommand(q, conn);
            SqlDataReader rdr = cmd.ExecuteReader();


            if (rdr.HasRows)
                while (rdr.Read())
                {
                    {
                        if ((rdr["username"].Equals(username)) && rdr["password"].Equals(password))
                        {
                            Console.WriteLine("login succcesfully");
                        }
                    }
                }
            else
            {
                Console.WriteLine("invalid credientials!!!");
            }





        }


    }




}